package com.ilyabarr.repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ilyabarr.model.Player;
import com.ilyabarr.service.CacheService;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Repository;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


@Slf4j
@Repository
public class PlayerRepository {

    private static final String BASE_CSV_FILE = "players.csv";
    private static final String ADDITIONAL_DATA_URL = "https://www.balldontlie.io/api/v1/players/";

    @Autowired
    private CacheService cacheService;

    @Autowired
    private SimpMessagingTemplate messagingTemplate;

    //Another option is to use Jackson CsvMapper
    public void loadPlayersInfo() {
        try {
            File csvFile = new File(BASE_CSV_FILE);
            FileReader fileReader = new FileReader(csvFile);
            CSVReader csvReader = new CSVReader(fileReader);

            List<Player> players = new ArrayList<>();

            String[] line;
            while ((line = csvReader.readNext()) != null) {
                Player player = new Player();
                player.setId(Integer.parseInt(line[0]));
                player.setNickName(line[1]);

                players.add(player);
            }
            csvReader.close();

            cacheService.batchUpdateAndSaveCache(players);
        } catch (IOException e) {
            log.error("Error parsing csv file!\n" + "cause: " + e.getCause() + "\nException message: " + e.getMessage());
        } catch (CsvValidationException e) {
            throw new RuntimeException(e);
        }
    }

    public void retrieveAdditionalDataAndUpdateCache() {
        List<Player> players = new ArrayList<>();
        for (Player csvPlayer : cacheService.getAllPlayers()) {
            try {
                URL url = new URL(ADDITIONAL_DATA_URL + csvPlayer.getId());
                // JSON URL to Java object
                ObjectMapper mapper = new ObjectMapper();
                Player player = mapper.readValue(url, Player.class);
                // Add the player to the list to batch update
                players.add(player);
                messagingTemplate.convertAndSend("/topic/playerUpdates", "Player " + player.getId() + " details updated");
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        // Batch update the cache and save to file
        cacheService.batchUpdateAndSaveCache(players);
    }

    public String createCsv() {
        StringWriter writer = new StringWriter();
        try {
            for (Player player : cacheService.getAllPlayers()) {
                writer.write(player.getId() + "," + player.getFirstName() + "," + player.getLastName());

                Map<String, Object> additionalProperties = player.getAdditionalProperties();
                for (Map.Entry<String, Object> entry : additionalProperties.entrySet()) {
                    writer.write("," + entry.getValue());
                }
                writer.write("\n");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return writer.toString();
    }
}
