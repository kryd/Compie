package com.ilyabarr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlayersDataApp {

    public static void main(String[] args) {
        SpringApplication.run(PlayersDataApp.class, args);
    }
}