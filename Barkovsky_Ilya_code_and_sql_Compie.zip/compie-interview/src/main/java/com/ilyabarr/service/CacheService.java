package com.ilyabarr.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ilyabarr.model.Player;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class CacheService {

    private final Map<Integer, Player> playerCache = new HashMap<>(); //id -> player
    private final ObjectMapper objectMapper = new ObjectMapper();

    private static final String CACHE_FILE_PATH = "player_cache.json";

    public CacheService() {
        loadCacheFromFile();
    }

    public Player getPlayerFromCache(int playerId) {
        return playerCache.get(playerId);
    }

    public void updatePlayerCache(Player player) {
        playerCache.put(player.getId(), player);
    }

    public List<Player> getAllPlayers() {
        return new ArrayList<>(playerCache.values());
    }

    public void batchUpdateAndSaveCache(List<Player> playersToUpdate) {
        for (Player player : playersToUpdate) {
            playerCache.put(player.getId(), player);
        }
        saveCacheToFile();
    }

    private void loadCacheFromFile() {
        try {
            File cacheFile = new File(CACHE_FILE_PATH);
            if (cacheFile.exists()) {
                playerCache.clear();
                playerCache.putAll(objectMapper.readValue(cacheFile, new TypeReference<Map<Integer, Player>>() {
                }));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveCacheToFile() {
        try {
            File cacheFile = new File(CACHE_FILE_PATH);
            objectMapper.writeValue(cacheFile, playerCache);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}