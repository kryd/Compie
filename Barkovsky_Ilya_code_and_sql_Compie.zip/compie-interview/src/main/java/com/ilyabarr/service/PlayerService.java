package com.ilyabarr.service;

import com.ilyabarr.repository.PlayerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class PlayerService {

    @Autowired
    private PlayerRepository playerRepository;

    public String processPlayerDetails() {
        playerRepository.loadPlayersInfo();
        playerRepository.retrieveAdditionalDataAndUpdateCache();
        return playerRepository.createCsv();
    }

    // Scheduled job to update player cache every 15 minutes
    @Scheduled(fixedRate = 15 * 60 * 1000)
    public void updatePlayerCacheJob() {
        playerRepository.retrieveAdditionalDataAndUpdateCache();
    }
}
